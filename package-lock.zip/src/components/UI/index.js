import SearchInput from "./SearchInput.vue"
import DataBlock from "./DataBlock.vue"

export default [SearchInput, DataBlock]