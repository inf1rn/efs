<template>
  <footer class="footer footer-no--bg">
    <div class="footer__inner">© Все права защищены</div>
  </footer>
</template>
<script>
export default {
  name: "CabinetFooter",
};
</script>