<template>
    <router-view/>
</template>
<script>
    export default {
        name: "cabinet-subjects"
    }
</script>