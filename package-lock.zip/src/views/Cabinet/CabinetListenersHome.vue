<template>
  <router-view />
</template>
<script>
export default {
  name: "cabinet-listeners-home",
};
</script>