import { messagesAllModule } from "./messagesAllModule";

export const messagesModule = {
    modules: {
        messagesAll: messagesAllModule
    },
    namespaced: true
}