<template>
  <div class="popup-new popup_events _active">
    <div class="popup__content">
      <div class="popup__body">
        <div class="popup__close"></div>
        <div class="popup__body-wrap body-wrap">
          <div class="body-wrap__content events-content">
            <div class="events-content__box-title">
              <h2 class="events-content__title events-title2">
                запись отменена
              </h2>
              <h5 class="events-content__title events-title events-title--bold">
                Повторно записаться на мероприятие можно в личном кабинете в
                разделе <a href="" class="events-title__link">«Мероприятия»</a>
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
