<template>
  <div class="popup-new popup_events _active">
    <div class="popup__content">
      <div class="popup__body">
        <div class="popup__close"></div>
        <div class="popup__body-wrap body-wrap">
          <div class="body-wrap__content events-content">
            <div class="events-content__box-title">
              <h2 class="events-content__title events-title2">
                Спасибо за участие
              </h2>
              <h5 class="events-content__title events-title events-title--bold">
                Подробная информация по мероприятию отправлена вам на e-mail.
              </h5>
            </div>
            <p class="events-content__text">
              Отменить участие можно через личный кабинет в разделе
              <a href="#" class="events-content__text-link"
                >«Участие в мероприятиях»</a
              >
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
