<template>
  <main class="content content_cabinet">
    <section class="page__section">
      <!-- <ul class="breadcrumbs page__breadcrumbs">
			<li class="breadcrumbs__item">
				<a href="#" class="breadcrumbs__link">мероприятия</a>
			</li>
			<li class="breadcrumbs__item">
				<a href="#" class="breadcrumbs__link">мои мероприятия</a>
			</li>
			<li class="breadcrumbs__item">
				<span href="#" class="breadcrumbs__link breadcrumbs__link_current">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</span>
			</li>
        </ul>		 -->
      <h1 class="section-title mb-50">
        Мастер-класс как эффективная форма повышения профессионального
        мастерства педагогов
      </h1>
      <div class="content-inner">
        <div class="content__right content__right-polls events-content">
          <div class="content__right-wr">
            <div class="events-content__item">
              <div class="events-title">
                Тема «Педагогическое взаимодействие в структуре методической
                работы как условие совершенствования профессионально-личностных
                компетенций педагога»
              </div>
            </div>
            <div class="events-content__item events-content__item--flex">
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Дата начала опроса</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">23.10.2021</div>
                </div>
              </div>
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Дата конца опроса</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">23.10.2021</div>
                </div>
              </div>
            </div>
            <div class="events-content__item events-content__item--flex">
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Прошли опрос</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">16/34</div>
                </div>
              </div>
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Всего вопросов</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">12</div>
                </div>
              </div>
            </div>
          </div>
          <div class="content__right-wr">
            <div class="events-content__item">
              <div class="events-content__item-name">Дата начала опроса</div>
              <div class="events-title">
                Тема «Педагогическое взаимодействие в структуре методической
                работы как условие совершенствования профессионально-личностных
                компетенций педагога»
              </div>
            </div>
            <div class="events-content__item">
              <label class="form-block__inner">
                <div class="form-block__name name-title">
                  Вопрос 1. введите ответ
                </div>
                <input
                  type="text"
                  class="form-block__input form-block__input-bbn"
                  placeholder="Текстовый ответ"
                />
              </label>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">
                Вопрос 2. Выберите один вариант ответа
              </div>
              <div class="events-content__item-radio box-radio">
                <label class="wr-radio">
                  <input
                    type="radio"
                    name="Вопрос 2"
                    value="Вариант 1"
                    class="real-radio"
                    checked
                  />
                  <span class="custom-radio custom-radio--mb"></span>
                  <span class="text-radio">Вариант 1</span>
                </label>
                <label class="wr-radio">
                  <input
                    type="radio"
                    name="Вопрос 2"
                    value="Вариант 2"
                    class="real-radio"
                  />
                  <span class="custom-radio custom-radio--mb"></span>
                  <span class="text-radio">Вариант 2</span>
                </label>
                <label class="wr-radio">
                  <input
                    type="radio"
                    name="Вопрос 2"
                    value="Вариант 3"
                    class="real-radio"
                  />
                  <span class="custom-radio"></span>
                  <span class="text-radio">Вариант 3</span>
                </label>
              </div>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">
                Вопрос 3. выберите несколько вариантов ответа
              </div>
              <div class="events-content__item-radio">
                <label class="wr-checkbox wr-checkbox--mb">
                  <input
                    type="checkbox"
                    name="coding-notes"
                    class="real-checkbox"
                  />
                  <span class="custom-checkbox custom-checkbox--grey"></span>
                  <span class="text-checkbox text-checkbox--grey"
                    >Вариант 1</span
                  >
                </label>
                <label class="wr-checkbox wr-checkbox--mb">
                  <input
                    type="checkbox"
                    name="coding-notes"
                    class="real-checkbox"
                  />
                  <span class="custom-checkbox custom-checkbox--grey"></span>
                  <span class="text-checkbox text-checkbox--grey"
                    >Вариант 2</span
                  >
                </label>
                <label class="wr-checkbox wr-checkbox--mb">
                  <input
                    type="checkbox"
                    name="coding-notes"
                    class="real-checkbox"
                  />
                  <span class="custom-checkbox custom-checkbox--grey"></span>
                  <span class="text-checkbox text-checkbox--grey"
                    >Вариант 3</span
                  >
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="content__left content__left--height">
          <div class="content__left-title">Участники - 345</div>
          <div class="content__left-list list">
            <div class="list__item list__item--icon" data-akkardion>
              Рогалевич И.А.
            </div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item list__item--icon" data-akkardion>
              Рогалевич И.А.
            </div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item list__item--icon" data-akkardion>
              Рогалевич И.А.
            </div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
            <div class="list__item" data-akkardion>Рогалевич И.А.</div>
            <div class="list__item-hidden hidden">
              <div class="list__item-info">
                <div class="list__item-info-name">Электронная почта</div>
                <a href="mailto:" class="list__item-info-link"
                  >ivanovasg@mail.ru</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Мобильный телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Организация</div>
                <a href="mailto:" class="list__item-info-link"
                  >Высший колледж связи г. Москва</a
                >
              </div>
              <div class="list__item-info">
                <div class="list__item-info-name">Рабочий телефон</div>
                <a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
              </div>
            </div>
          </div>
          <div class="content__left-btn">
            <button
              type="submit"
              class="
                button
                button_theme_green--empty
                button_border_small
                form__submit
                button_news
              "
            >
              Добавить участника
            </button>
          </div>
        </div>
      </div>
      <div class="statistics">
        <h2 class="statistic__title title2">Статистика</h2>
        <div class="statistics-wr">
          <div class="statistics__qustion">
            <div class="statistics__qustion-form form__item">
              <label for="reportsRegion" class="form__label">Вопрос</label>
              <select name="reportsRegion" class="two">
                <option value="1" selected>2</option>
                <option value="2">Пункт №2</option>
                <option value="3">Пункт №3</option>
                <option value="4">Пункт №4</option>
              </select>
            </div>
          </div>
          <div class="statistics__ell ell-img">
            <div class="ell-img__answer ell-img__answer--top">Вариант 1</div>
            <div class="ell-img__answer ell-img__answer--left">Вариант 2</div>
            <div class="ell-img__answer ell-img__answer--right">Вариант 3</div>
            <div class="ell-img__icon ell-img__icon--top">
              <svg
                width="215"
                height="127"
                viewBox="0 0 215 127"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <mask id="path-1-inside-1_0_4306" fill="white">
                  <path
                    d="M0.590934 83.4883C8.02659 62.825 20.7337 44.4639 37.4526 30.2251C54.1715 15.9864 74.3215 6.36457 95.9051 2.31349C117.489 -1.73758 139.756 -0.0772211 160.5 7.12998C181.244 14.3372 199.745 26.8409 214.167 43.4017L119.148 126.151L0.590934 83.4883Z"
                  />
                </mask>
                <path
                  d="M0.590934 83.4883C8.02659 62.825 20.7337 44.4639 37.4526 30.2251C54.1715 15.9864 74.3215 6.36457 95.9051 2.31349C117.489 -1.73758 139.756 -0.0772211 160.5 7.12998C181.244 14.3372 199.745 26.8409 214.167 43.4017L119.148 126.151L0.590934 83.4883Z"
                  fill="#303F95"
                  stroke="#F5F6F8"
                  stroke-width="4"
                  mask="url(#path-1-inside-1_0_4306)"
                />
              </svg>
            </div>
            <div class="ell-img__icon ell-img__icon--left">
              <svg
                width="146"
                height="170"
                viewBox="0 0 146 170"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <mask id="path-1-inside-1_0_4305" fill="white">
                  <path
                    d="M145.9 168.419C124.216 171.887 102.001 169.628 81.4582 161.864C60.9156 154.101 42.7588 141.104 28.7876 124.161C14.8164 107.218 5.51612 86.9173 1.80862 65.2721C-1.89888 43.6268 0.115213 21.3884 7.65123 0.761497L126 44L145.9 168.419Z"
                  />
                </mask>
                <path
                  d="M145.9 168.419C124.216 171.887 102.001 169.628 81.4582 161.864C60.9156 154.101 42.7588 141.104 28.7876 124.161C14.8164 107.218 5.51612 86.9173 1.80862 65.2721C-1.89888 43.6268 0.115213 21.3884 7.65123 0.761497L126 44L145.9 168.419Z"
                  fill="#303F95"
                  stroke="#F5F6F8"
                  stroke-width="4"
                  mask="url(#path-1-inside-1_0_4305)"
                />
              </svg>
            </div>
            <div class="ell-img__icon ell-img__icon--right">
              <svg
                width="127"
                height="208"
                viewBox="0 0 127 208"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <mask id="path-1-inside-1_0_4307" fill="white">
                  <path
                    d="M95.2131 0.446031C110.003 17.4366 119.968 38.0814 124.069 60.2309C128.171 82.3803 126.26 105.224 118.535 126.384C110.81 147.544 97.5533 166.246 80.1458 180.543C62.7383 194.84 41.8163 204.209 19.5584 207.674L0.175755 83.174L95.2131 0.446031Z"
                  />
                </mask>
                <path
                  d="M95.2131 0.446031C110.003 17.4366 119.968 38.0814 124.069 60.2309C128.171 82.3803 126.26 105.224 118.535 126.384C110.81 147.544 97.5533 166.246 80.1458 180.543C62.7383 194.84 41.8163 204.209 19.5584 207.674L0.175755 83.174L95.2131 0.446031Z"
                  fill="#303F95"
                  stroke="#F5F6F8"
                  stroke-width="4"
                  mask="url(#path-1-inside-1_0_4307)"
                />
              </svg>
            </div>
          </div>
        </div>
        <div class="statistics-table">
          <table class="table users__table">
            <tbody>
              <tr class="table__row table__row_head">
                <th class="table__header">Учитель</th>
                <th class="table__header">Вопрос 1</th>
                <th class="table__header">Вопрос 2</th>
                <th class="table__header">Вопрос 3</th>
              </tr>
              <tr class="table__row">
                <td class="table__cell">Иванова Светлана Геннадьевна</td>
                <td class="table__cell">да будет так</td>
                <td class="table__cell">3</td>
                <td class="table__cell">2,3</td>
              </tr>
              <tr class="table__row">
                <td class="table__cell">Смирнова Наталья Петровна</td>
                <td class="table__cell">я против</td>
                <td class="table__cell">1</td>
                <td class="table__cell">1,3</td>
              </tr>
              <tr class="table__row">
                <td class="table__cell">Иванова Светлана Геннадьевна</td>
                <td class="table__cell">да будет так</td>
                <td class="table__cell">3</td>
                <td class="table__cell">2,3</td>
              </tr>
              <tr class="table__row">
                <td class="table__cell">Смирнова Наталья Петровна</td>
                <td class="table__cell">я против</td>
                <td class="table__cell">1</td>
                <td class="table__cell">1,3</td>
              </tr>
            </tbody>
          </table>
          <div class="table-pagination table-pagination_nopadd">
            <div class="table-pagination__count">1-10 из 1240</div>
            <div class="table-pagination__bullets">
              <button class="bullets-left _disabled">
                <img src="images/table-pagination/left.svg" alt="left" />
              </button>
              <button class="bullets-right">
                <img src="images/table-pagination/right.svg" alt="right" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>
