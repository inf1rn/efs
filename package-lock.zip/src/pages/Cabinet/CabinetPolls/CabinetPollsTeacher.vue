<template>
  <main class="content content_federal">
    <section class="users page__section">
      <div class="users__top">
        <h1 class="section-title">опросы</h1>
      </div>
      <div class="form-detail__wrapper wrapper-max_width-m">
        <div class="events-wrap">
          <div class="events-row events-row--jc">
            <h3 class="events__title events__title--icon">Текущие опросы</h3>
          </div>
          <div class="events-row events-card-wr">
            <article class="events-card">
              <div class="events-card__title">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user">
                  <span>32</span> из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <button
                  type="submit"
                  class="
                    button button_theme_green button_border_small
                    form__submit
                    button_news
                  "
                >
                  Пройти опрос
                </button>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user">
                  <span>32</span> из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <button
                  type="submit"
                  class="
                    button button_theme_green button_border_small
                    form__submit
                    button_news
                  "
                >
                  Пройти опрос
                </button>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user">
                  <span>32</span> из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <button
                  type="submit"
                  class="
                    button button_theme_green button_border_small
                    form__submit
                    button_news
                  "
                >
                  Продолжить опрос
                </button>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user">
                  <span>32</span> из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <button
                  type="submit"
                  class="
                    button button_theme_green button_border_small
                    form__submit
                    button_news
                  "
                >
                  Пройти опрос
                </button>
              </div>
            </article>
          </div>
          <div class="events-row events-row--jc">
            <h3 class="events__title">Завершенные опросы</h3>
          </div>
          <div class="events-row events-card-wr">
            <article class="events-card">
              <div class="events-card__title events-card__title--grey">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal-grey">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user-grey">
                  32 из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q-grey">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <a href="#" class="new-card-btn__link">Подробнее</a>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title events-card__title--grey">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal-grey">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user-grey">
                  32 из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q-grey">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <a href="#" class="new-card-btn__link">Подробнее</a>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title events-card__title--grey">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal-grey">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user-grey">
                  32 из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q-grey">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <a href="#" class="new-card-btn__link">Подробнее</a>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title events-card__title--grey">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal-grey">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user-grey">
                  32 из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q-grey">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <a href="#" class="new-card-btn__link">Подробнее</a>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title events-card__title--grey">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal-grey">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user-grey">
                  32 из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q-grey">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <a href="#" class="new-card-btn__link">Подробнее</a>
              </div>
            </article>
            <article class="events-card">
              <div class="events-card__title events-card__title--grey">
                «Мастер-класс как эффективная форма повышения профессионального
                мастерства педагогов»
              </div>
              <div class="events-card__wr-text">
                <div class="events-card__text events-card__text--cal-grey">
                  20 января 2022 - 23 января 2022
                </div>
                <div class="events-card__text events-card__text--user-grey">
                  32 из 48 прошли опрос
                </div>
                <div class="events-card__text events-card__text--q-grey">
                  Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                </div>
              </div>
              <div class="events-card__btn">
                <a href="#" class="new-card-btn__link">Подробнее</a>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>
