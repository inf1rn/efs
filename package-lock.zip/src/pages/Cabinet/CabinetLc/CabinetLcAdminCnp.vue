<template>
  <main class="content cabinet-subject content_cabinet">
    <section class="region-detail-detail-page page__section">
      <ul class="breadcrumbs page__breadcrumbs">
        <li class="breadcrumbs__item">
          <a href="#" class="breadcrumbs__link">Регионы</a>
        </li>
        <li class="breadcrumbs__item">
          <a href="#" class="breadcrumbs__link">Республика Саха (Якутия)</a>
        </li>
        <li class="breadcrumbs__item">
          <span href="#" class="breadcrumbs__link breadcrumbs__link_current">
            ИРО Сахалинской области
          </span>
        </li>
      </ul>
      <article class="organization-detail">
        <h1 class="section-title">ИРО Сахалинской области</h1>
        <p class="section-subtitle">
          Институт развития образования Сахалинской области
        </p>
        <div class="organization-detail__description">
          <div class="organization-detail__text-area">
            <p class="organization-detail__text">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit quos
              mollitia facere nostrum molestias architecto ullam dolore
              dignissimos. Lorem ipsum dolor sit amet consectetur adipisicing
              elit. Similique, a.
            </p>
            <p class="organization-detail__text">
              Illum nemo placeat numquam voluptates laudantium, laborum
              repellendus, incidunt tempore modi doloribus porro perferendis
              illo tenetur. Numquam, blanditiis! Lorem ipsum dolor sit amet
              consectetur adipisicing elit. Voluptatibus delectus odit
              asperiores praesentium fugiat doloribus aperiam itaque esse.
            </p>
            <p class="organization-detail__text">
              Consequuntur molestiae minus ducimus adipisci eligendi aspernatur
              eum cupiditate rerum! Soluta deleniti est culpa beatae, incidunt
              excepturi quae.
            </p>
          </div>
          <div class="organization-detail__contacts-area">
            <ul class="organization-detail__contacts">
              <li class="organization-detail__contacts-item">
                <div class="hex organization-detail__contacts-hex">
                  <img src="./images/contacts__phone.svg" alt="" />
                </div>
                <div class="organization-detail__text-box">
                  <p class="organization-detail__contacts-name">Телефон</p>
                  <p class="organization-detail__contacts-value">
                    +7 (424) 245-41-00
                  </p>
                </div>
              </li>
              <li class="organization-detail__contacts-item">
                <div class="hex organization-detail__contacts-hex">
                  <img src="./images/contacts__map-pin.svg" alt="" />
                </div>
                <div class="organization-detail__text-box">
                  <p class="organization-detail__contacts-name">Адрес</p>
                  <p class="organization-detail__contacts-value">
                    Пограничная ул., 42, Южно-Сахалинск, Сахалинская обл.
                  </p>
                </div>
              </li>
              <li class="organization-detail__contacts-item">
                <div class="hex organization-detail__contacts-hex">
                  <img src="./images/contacts__email.svg" alt="" />
                </div>
                <div class="organization-detail__text-box">
                  <p class="organization-detail__contacts-name">E-mail</p>
                  <p class="organization-detail__contacts-value">
                    sahalineducation@gmail.com
                  </p>
                </div>
              </li>
              <li class="organization-detail__contacts-item">
                <div class="hex organization-detail__contacts-hex">
                  <img src="./images/world.svg" alt="" />
                </div>
                <div class="organization-detail__text-box">
                  <p class="organization-detail__contacts-name">Сайт</p>
                  <p class="organization-detail__contacts-value">
                    https://iroasoumo.ru/
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </article>
    </section>
    <section
      class="
        org-team-section
        page__section page__section_width_full page__section_mt_m
      "
    >
      <div class="org-team org-team-section__inner">
        <div class="org-team__director-area">
          <svg
            class="org-team__director-photo"
            width="200"
            height="230"
            viewBox="0 0 200 230"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            xmlns:xlink="http://www.w3.org/1999/xlink"
          >
            <path
              d="M0 172.5L100 230L200 172.5V57.5L100 0L0 57.5V172.5Z"
              fill="url(#pattern0)"
            />
            <defs>
              <pattern
                id="pattern0"
                patternContentUnits="objectBoundingBox"
                width="1"
                height="1"
              >
                <use
                  xlink:href="#image0"
                  transform="translate(-0.075) scale(0.0014393 0.00125156)"
                />
              </pattern>
              <image
                id="image0"
                width="799"
                height="799"
                xlink:href="./upload/director-photo.png"
              />
            </defs>
          </svg>
          <p class="org-team__director-position">Директор</p>
          <p class="org-team__director-name">
            Константипольский Константин Константинович
          </p>
          <p class="org-team__director-bio">
            Стаж руководящей должности 15 лет, Кандидат педагогических наук.
          </p>
        </div>
        <ul class="org-team__team-area">
          <li class="org-team__person">
            <p class="org-team__person-name">
              Константипольский Константин Константинович
            </p>
            <p class="org-team__person-position">Заместитель</p>
            <p class="org-team__person-bio">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu massa,
              tellus ullamcorper pharetra tortor neque.
            </p>
          </li>
          <li class="org-team__person">
            <p class="org-team__person-name">
              Константипольский Константин Константинович
            </p>
            <p class="org-team__person-position">Заместитель</p>
            <p class="org-team__person-bio">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu massa,
              tellus ullamcorper pharetra tortor neque.
            </p>
          </li>
          <li class="org-team__person">
            <p class="org-team__person-name">
              Константипольский Константин Константинович
            </p>
            <p class="org-team__person-position">Заместитель</p>
            <p class="org-team__person-bio">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu massa,
              tellus ullamcorper pharetra tortor neque.
            </p>
          </li>
          <li class="org-team__person">
            <p class="org-team__person-name">
              Константипольский Константин Константинович
            </p>
            <p class="org-team__person-position">Заместитель</p>
            <p class="org-team__person-bio">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu massa,
              tellus ullamcorper pharetra tortor neque.
            </p>
          </li>
        </ul>
      </div>
    </section>
    <section
      class="programs-section page__section_width_content page__section_mt_m"
    >
      <h2 class="programs-section__title section-title">
        Правовые документы (12)
      </h2>
      <ul class="program-list program-list--col1">
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
        <li class="program-list__item-box">
          <a href="#" class="program-list__item-box-link"
            >Презентация выступления И.А. Рогалевич
            <span>(.ppt 7,6 MБ)</span></a
          >
          <div class="form__item-down"></div>
        </li>
      </ul>
      <div class="programs-section__btn-down btn-down">
        <button class="btn-down__text">Показать еще документы</button>
        <div class="btn-down__icon">
          <svg
            width="22"
            height="12"
            viewBox="0 0 22 12"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M1 1L11 11L21 1"
              stroke="#2FD385"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </div>
      </div>
    </section>
    <section class="methodist-activ">
      <h2 class="programs-section__title section-title">
        Региональный методический актив
      </h2>
      <div class="methodist-activ__wr">
        <div class="methodist-activ-block">
          <div class="methodist-activ-title">География</div>
          <ul class="methodist-active__list active-list">
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
          </ul>
        </div>
        <div class="methodist-activ-block">
          <div class="methodist-activ-title">Химия</div>
          <ul class="methodist-active__list active-list">
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
          </ul>
        </div>
        <div class="methodist-activ-block">
          <div class="methodist-activ-title">Физика</div>
          <ul class="methodist-active__list active-list">
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
          </ul>
        </div>
        <div class="methodist-activ-block">
          <div class="methodist-activ-title">Биология</div>
          <ul class="methodist-active__list active-list">
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
          </ul>
        </div>
        <div class="methodist-activ-block">
          <div class="methodist-activ-title">Иностранные языки</div>
          <ul class="methodist-active__list active-list">
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
            <li class="active-item">
              <span class="active-item__text active-item__text--name"
                >Смирнова Н. Е.</span
              >
              <span class="active-item__text active-item__text--speciality"
                >Ведущий эксперт</span
              >
              <a href="#" class="active-item__text active-item__text--link"
                >+7 424 245-41-00</a
              >
              <a href="#" class="active-item__text active-item__text--link"
                >sahalineducation@efs.com</a
              >
            </li>
          </ul>
        </div>
      </div>
    </section>
    <button type="submit" class="button button_theme_green button_border_small">
      Редактировать
    </button>
  </main>
</template>
