<template>
  <div class="popup-new popup_events _active">
    <div class="popup__content">
      <div class="popup__body">
        <div class="popup__close"></div>
        <div class="popup__body-wrap body-wrap">
          <div class="body-wrap__content events-content">
            <h5 class="events-content__title events-title events-title--bold">
              Мастер-класс как эффективная форма повышения профессионального
              мастерства педагогов
            </h5>
            <div class="events-content__item events-content__item--flex">
              <div class="events-content__item-time item-time">
                <div class="events-content__item-name">начало мероприятия</div>
                <div class="events-content__item-info">
                  <span class="events-content__item-info-num events-title"
                    >23.10.2021</span
                  >
                  <span class="events-content__item-info-num events-title"
                    >11:00 MSK</span
                  >
                </div>
              </div>
              <div class="events-content__item-time item-time">
                <div class="events-content__item-name">конец мероприятия</div>
                <div class="events-content__item-info">
                  <span class="events-content__item-info-num events-title"
                    >23.10.2021</span
                  >
                  <span class="events-content__item-info-num events-title"
                    >11:00 MSK</span
                  >
                </div>
              </div>
              <div
                class="
                  events-content__item-time
                  item-time
                  events-content__item-time--not-r
                "
              >
                <div class="events-content__item-name">занято мест</div>
                <div class="events-content__item-info">
                  <span class="events-content__item-info-num events-title"
                    >334/500
                  </span>
                </div>
              </div>
              <div class="events-content__item-time item-time">
                <div class="events-content__item-name">начало мероприятия</div>
                <div class="events-content__item-info">
                  <span
                    class="
                      events-content__item-info-num
                      events-title events-title--green
                    "
                    >Онлайн</span
                  >
                </div>
              </div>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">ссылка на мероприятия</div>
              <div class="events-content__item-link events-title">
                https://www.google.com/webhp?hl=ru&sa=X&ved
              </div>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">Описание мероприятия</div>
              <div class="events-title">
                Тема «Педагогическое взаимодействие в структуре методической
                работы как условие совершенствования профессионально-личностных
                компетенций педагога»
              </div>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">материалы мероприятия</div>
              <ol class="events-content__item-list">
                <li class="events-content__item-box">
                  <a href="#" class="events-content__item-box-link"
                    >Презентация выступления И.А. Рогалевич
                    <span>(.ppt 7,6 MБ)</span></a
                  >
                </li>
                <li class="events-content__item-box">
                  <a href="#" class="events-content__item-box-link"
                    >Презентация к игре «Осторожно! Критика»
                    <span>(.ppt 511 КБ)</span></a
                  >
                </li>
                <li class="events-content__item-box">
                  <a href="#" class="events-content__item-box-link"
                    >Сценарий проведения деловой игры
                    <span>(.doc 33 КБ)</span></a
                  >
                </li>
              </ol>
            </div>
            <div class="events-content__item-btn">
              <button
                type="submit"
                class="
                  button button_theme_green button_border_small
                  form__submit
                  button_news
                "
              >
                Записаться
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>