<template>
  <div class="popup-new popup-cabinet _active">
    <div class="popup__content">
      <div class="popup__body">
        <div class="popup__close"></div>
        <div class="popup__body-wrap body-wrap">
          <div class="popup-cabinet__title">Выбрано 16 файлов</div>
          <input
            type="search"
            name="search"
            class="
              form__input-edit
              popup-cabinet__search
              form__input-edit_type_search
            "
            id="search"
          />
          <ul class="popup-cabinet__list cabinet-list">
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
            <li class="cabinet-item">
              <div class="cabinet-item__checkbox checkbox form-group">
                <input type="checkbox" id="chk" />
                <label for="chk"></label>
              </div>
              <div class="cabinet-item__text-wr">
                <div class="cabinet-item__name">Павлова Диана Ивановна</div>
                <div class="cabinet-item__adress">Белгород, Школа номер 11</div>
              </div>
            </li>
          </ul>
          <div class="popup-cabinet__mes">
            <label class="popup-cabinet__mes-comment form-textarea">
              <div class="popup-cabinet__mes-text form-textarea__text">
                Добавить комментарий
              </div>
              <textarea
                class="popup-cabinet__mes-field form-textarea__field"
              ></textarea>
            </label>
            <button class="popup-cabinet__mes-btn">
              <svg
                width="34"
                height="34"
                viewBox="0 0 34 34"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <g clip-path="url(#clip0_0_5011)">
                  <path
                    d="M31.1129 16.9706H15.5565"
                    stroke="white"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M31.1128 16.9707L12.021 26.1631L15.5565 16.9707L12.021 7.77836L31.1128 16.9707Z"
                    stroke="white"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_0_5011">
                    <rect
                      width="24"
                      height="24"
                      fill="white"
                      transform="translate(16.9707) rotate(45)"
                    />
                  </clipPath>
                </defs>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>