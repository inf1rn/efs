<template>

    <main class="content content_cabinet">
		<section class="page__section">
			<!-- <ul class="breadcrumbs page__breadcrumbs">
				<li class="breadcrumbs__item">
					<a href="#" class="breadcrumbs__link">мероприятия</a>
				</li>
				<li class="breadcrumbs__item">
					<a href="#" class="breadcrumbs__link">создать мероприятие</a>
				</li>
				<li class="breadcrumbs__item">
					<span href="#" class="breadcrumbs__link breadcrumbs__link_current">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</span>
				</li>
			</ul>		 -->
			<h1 class="section-title mb-50">Предметные кабинеты</h1>
			<div class="wrapper wrapper--width cabinet">
				<div class="tabs profile__tabs _tabs">
                    <nav class="tabs__navigation">
                        <button type="submit" class="tabs__title _tabs-item _active">Все кабинеты</button>
                        <button type="submit" class="tabs__title _tabs-item">Мои кабинеты</button>
                    </nav>
                    <div class="tabs__content">
                        <div class="tabs__body _tabs-block _active">
							<div class="cabinet-radio cabinet-radio--flex  box-radio">
								<label class="wr-radio">									
									<span class="text-radio text-radio--mb text-radio--bold">Начальное общее образование</span>
									<a href="#" class="text-link">Русский язык</a>
									<a href="#" class="text-link">Русская литература</a>
								</label>
								<label class="wr-radio">									
									<span class="text-radio text-radio--mb  text-radio--bold">Основное общее образование</span>
									<a href="#" class="text-link">Русский язык</a>
									<a href="#" class="text-link">Русская литература</a>
								</label>
								<label class="wr-radio">									
									<span class="text-radio text-radio--mb  text-radio--bold">Среднее общее образование</span>
									<a href="#" class="text-link">Русский язык</a>
									<a href="#" class="text-link">Русская литература</a>
								</label>
							</div>
                        </div>
                        <div class="tabs__body _tabs-block">
							<div class="cabinet-radio cabinet-radio--flex  box-radio">
								<label class="wr-radio">									
									<span class="text-radio text-radio--mb text-radio--bold">Начальное общее образование</span>
									<a href="#" class="text-link">Русский язык</a>
									<a href="#" class="text-link text-link--active">Русская литература</a>
								</label>
								<label class="wr-radio">									
									<span class="text-radio text-radio--mb  text-radio--bold">Основное общее образование</span>
									<a href="#" class="text-link">Русский язык</a>
									<a href="#" class="text-link">Русская литература</a>
								</label>
								<label class="wr-radio">									
									<span class="text-radio text-radio--mb  text-radio--bold">Среднее общее образование</span>
									<a href="#" class="text-link">Русский язык</a>
									<a href="#" class="text-link">Русская литература</a>
								</label>
							</div>				
											
							<div class="cabinet__accordion accordion">								
								<div class="accordion__item" data-akkardion>
									Нормативные правовые документы						
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебниковnobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">												
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">								
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Образовательные ресурсы для методистов и педагогов (методические рекомендации, кейсы, инструкции, технологические карты и др.)						
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Формы методического сопровождения (семинары, вебинары, конференции, круглые столы и т.п.)						
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Методическое сопровождение формирования функциональной грамотности					
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Методическое сопровождение введения обновлённых ФГОС начального общего и основного общего образования					
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Банки контрольно-измерительных материалов, диагностических материалов, проверочных заданий					
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Внеурочная деятельность						
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
								<div class="accordion__item" data-akkardion>
									Библиотека (информационные материалы, полезные ресурсы, ссылки и др.)					
								</div>
								<div class="accordion__item-hidden hidden">								
									<ol class="events-content__item-list">
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный закон «Об образовании в Российской Федерации» <nobr>(.ppt 7,6 MБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральные государственные образовательные стандарты начального общего, основного общего и среднего общего образования<nobr>(.ppt 511 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
										<li class="events-content__item-box">
											<a href="#" class="events-content__item-box-link">Федеральный перечень учебников<nobr>(.doc 33 КБ)</nobr></a>
											<div class="events-content__item-box-icons form__item-btn form__item-btn--row">
												<div class="form__item-pen"></div>
												<div class="form__item-close"></div>
											</div>
										</li>
									</ol>													
								</div>
							</div>
                        </div>
                    </div>
                </div>				
											
			</div>		   
		</section>
    </main>
</template>
