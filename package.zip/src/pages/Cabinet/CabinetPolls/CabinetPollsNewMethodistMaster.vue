<template>
    <main class="content content_cabinet">
      <section class="page__section">
        <!-- <ul class="breadcrumbs page__breadcrumbs">
			<li class="breadcrumbs__item">
				<a href="#" class="breadcrumbs__link">мероприятия</a>
			</li>
			<li class="breadcrumbs__item">
				<a href="#" class="breadcrumbs__link">мои мероприятия</a>
			</li>
			<li class="breadcrumbs__item">
				<span href="#" class="breadcrumbs__link breadcrumbs__link_current">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</span>
			</li>
        </ul>		 -->
        <h1 class="section-title mb-50">Новый опрос</h1>
		<div class="content-inner">
			<div class="content__right content__right-polls events-content">
				<div class="content__right-wr">
					<div class="events-content__item events-content__item--line">
						<div class="events-content__item-name">Название опроса</div>
						<div class="events-title">Мастер-класс как эффективная форма повышения профессионального мастерства педагогов</div>
					</div>
					<div class="events-content__item events-content__item--line">
						<div class="events-content__item-name">Описание</div>
						<div class="events-title">Мастер-класс как эффективная форма повышения профессионального мастерства педагогов</div>
					</div>
					<div class="events-content__item events-content__item--flex">
						<div class="events-content__item-time events-content__item-time--width50 item-time">
							<div class="events-content__item-name">Дата начала опроса</div>
							<div class="events-content__item-info">
								<div class="events-content__item-inp-date inp-date">							
									<select name="form[]" class="two">
										<option value="1" selected>31.10.2020</option>
										<option value="2">Пункт №2</option>
										<option value="3">Пункт №3</option>
										<option value="4">Пункт №4</option>
									</select>
								</div>							
							</div>						
						</div>
						<div class="events-content__item-time events-content__item-time--width50 item-time">
							<div class="events-content__item-name">Дата конца опроса</div>
							<div class="events-content__item-info">
								<div class="events-content__item-inp-date inp-date">							
									<select name="form[]" class="two">
										<option value="1" selected>31.10.2020</option>
										<option value="2">Пункт №2</option>
										<option value="3">Пункт №3</option>
										<option value="4">Пункт №4</option>
									</select>
								</div>							
							</div>
						</div>					
					</div>
				</div>
				<div class="form-detail">
					<div class="form-detail__row row-spollers">
						<div data-spollers class="spollers">
							<div class="spollers__item">
								<button type="button" data-spoller class="spollers__title">
									<div class="spollers__title-edit">
										<ul>
											<li>
												<a href="#">Дублировать</a>
											</li>
											<li>
												 <a href="#">Выключить</a>
											 </li>
											 <li>
												 <a href="#">Удалить</a>
											 </li>
											 <li>
												 <a href="#">Вверх</a>
											 </li>
											 <li>
												 <a href="#">Вниз</a>
											 </li>
										</ul>
									</div>
								   <span>Вопрос 1</span>
								 </button>
								<div class="spollers__body">
									<div class="spollers__body-wrap">
										<div class="spollers__body-line">
											<div class="spollers__body-caption">
												Заголовок вопроса
											</div>
											<div class="spollers__body-info">
											 <input autocomplete="off" type="text" name="form[]"placeholder="Вопрос 1" class="spollers__body-input">
											</div>
										</div>
										<div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 Подсказка
											 </div>
											 <div class="spollers__body-info">
												 <input autocomplete="off" type="text" name="form[]"placeholder="" class="spollers__body-input">
	
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 тип поля
											 </div>
											 <div class="spollers__body-info">
												 <select name="form[]" class="select_form">
													 <option value="1" selected>Текстовый</option>
													 <option value="2">Пункт №2</option>
													 <option value="3">Пункт №3</option>
													 <option value="4">Пункт №4</option>
												 </select>
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="checkbox form-group">
												 <input type="checkbox" id="chk">
												 <label for="chk">Обязательное для заполнения</label>
											 </div>
										 </div>
										
									</div>
								</div>
							</div>							
							<div class="spollers__item">
								<button type="button" data-spoller class="spollers__title">
									<div class="spollers__title-edit">
										<ul>
											<li>
												<a href="#">Дублировать</a>
											</li>
											<li>
												 <a href="#">Выключить</a>
											 </li>
											 <li>
												 <a href="#">Удалить</a>
											 </li>
											 <li>
												 <a href="#">Вверх</a>
											 </li>
											 <li>
												 <a href="#">Вниз</a>
											 </li>
										</ul>
									</div>
								   <span>Вопрос 2</span>
								 </button>
								<div class="spollers__body">
									<div class="spollers__body-wrap">
										<div class="spollers__body-line">
											<div class="spollers__body-caption">
												Заголовок вопроса
											</div>
											<div class="spollers__body-info">
											 <input autocomplete="off" type="text" name="form[]"placeholder="Вопрос 2" class="spollers__body-input">
											</div>
										</div>
										<div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 Подсказка
											 </div>
											 <div class="spollers__body-info">
												 <input autocomplete="off" type="text" name="form[]"placeholder="" class="spollers__body-input">
	
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 тип поля
											 </div>
											 <div class="spollers__body-info">
												 <select name="form[]" class="select_form">
													 <option value="1" selected>Текстовый</option>
													 <option value="2">Пункт №2</option>
													 <option value="3">Пункт №3</option>
													 <option value="4">Пункт №4</option>
												 </select>
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="checkbox form-group">
												 <input type="checkbox" id="chk">
												 <label for="chk">Обязательное для заполнения</label>
											 </div>
										 </div>
										
									</div>
								</div>
							</div>							
							<div class="spollers__item">
								<button type="button" data-spoller class="spollers__title">
									<div class="spollers__title-edit">
										<ul>
											<li>
												<a href="#">Дублировать</a>
											</li>
											<li>
												 <a href="#">Выключить</a>
											 </li>
											 <li>
												 <a href="#">Удалить</a>
											 </li>
											 <li>
												 <a href="#">Вверх</a>
											 </li>
											 <li>
												 <a href="#">Вниз</a>
											 </li>
										</ul>
									</div>
								   <span>Вопрос 3</span>
								 </button>
								<div class="spollers__body">
									<div class="spollers__body-wrap">
										<div class="spollers__body-line">
											<div class="spollers__body-caption">
												Заголовок вопроса
											</div>
											<div class="spollers__body-info">
											 <input autocomplete="off" type="text" name="form[]"placeholder="Вопрос 3" class="spollers__body-input">
											</div>
										</div>
										<div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 Подсказка
											 </div>
											 <div class="spollers__body-info">
												 <input autocomplete="off" type="text" name="form[]"placeholder="" class="spollers__body-input">
	
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 тип поля
											 </div>
											 <div class="spollers__body-info">
												 <select name="form[]" class="select_form">
													 <option value="1" selected>Текстовый</option>
													 <option value="2">Пункт №2</option>
													 <option value="3">Пункт №3</option>
													 <option value="4">Пункт №4</option>
												 </select>
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="checkbox form-group">
												 <input type="checkbox" id="chk">
												 <label for="chk">Обязательное для заполнения</label>
											 </div>
										 </div>
										
									</div>
								</div>
							</div>							
							<div class="spollers__item">
								<button type="button" data-spoller class="spollers__title">
									<div class="spollers__title-edit">
										<ul>
											<li>
												<a href="#">Дублировать</a>
											</li>
											<li>
												 <a href="#">Выключить</a>
											 </li>
											 <li>
												 <a href="#">Удалить</a>
											 </li>
											 <li>
												 <a href="#">Вверх</a>
											 </li>
											 <li>
												 <a href="#">Вниз</a>
											 </li>
										</ul>
									</div>
								   <span>Вопрос 4</span>
								 </button>
								<div class="spollers__body">
									<div class="spollers__body-wrap">
										<div class="spollers__body-line">
											<div class="spollers__body-caption">
												Заголовок вопроса
											</div>
											<div class="spollers__body-info">
											 <input autocomplete="off" type="text" name="form[]"placeholder="Вопрос 4" class="spollers__body-input">
											</div>
										</div>
										<div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 Подсказка
											 </div>
											 <div class="spollers__body-info">
												 <input autocomplete="off" type="text" name="form[]"placeholder="" class="spollers__body-input">
	
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="spollers__body-caption">
												 тип поля
											 </div>
											 <div class="spollers__body-info">
												 <select name="form[]" class="select_form">
													 <option value="1" selected>Текстовый</option>
													 <option value="2">Пункт №2</option>
													 <option value="3">Пункт №3</option>
													 <option value="4">Пункт №4</option>
												 </select>
											 </div>
										 </div>
										 <div class="spollers__body-line">
											 <div class="checkbox form-group">
												 <input type="checkbox" id="chk">
												 <label for="chk">Обязательное для заполнения</label>
											 </div>
										 </div>
										
									</div>
								</div>
							</div>							
						</div>
					</div>
				</div>
				<div class="form-detail__btn">
					<button type="submit" class="button button_theme_green--empty button_border_small form__submit button_news">Добавить вопрос</button>
				</div>																		
			</div>
			<div class="content__left content__left--height">
				<div class="content__left-title">Участники - 345</div>				
				<div class="content__left-list list">
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
					<div class="list__item" data-akkardion>
						Рогалевич И.А.						
					</div>
					<div class="list__item-hidden hidden">
						<div class="list__item-info">
							<div class="list__item-info-name">Электронная почта</div>
							<a href="mailto:" class="list__item-info-link">ivanovasg@mail.ru</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Мобильный телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Организация</div>
							<a href="mailto:" class="list__item-info-link">Высший колледж связи г. Москва</a>
						</div>
						<div class="list__item-info">
							<div class="list__item-info-name">Рабочий телефон</div>
							<a href="tel:" class="list__item-info-link">+7 926 767 9644</a>
						</div>						
					</div>														
																			
																	
				</div>
				<div class="content__left-btn">
					<button type="submit" class="button button_theme_green--empty button_border_small form__submit button_news">Добавить участника</button>
				</div>				
			</div>
		</div>		
		<div class="events-content__item-button">
			<button type="submit" class="button button--mr button_theme_green button_border_small form__submit button_news">Опубликовать опрос</button>
			<button type="submit" class="button button_theme_green--empty button_border_small form__submit button_news">Сохранить в черновик</button>
		</div>   
      </section>
    </main>
</template>
