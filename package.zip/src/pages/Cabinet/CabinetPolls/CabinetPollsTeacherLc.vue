<template>
  <main class="content content_cabinet">
    <section class="page__section">
      <!-- <ul class="breadcrumbs page__breadcrumbs">
			<li class="breadcrumbs__item">
				<a href="#" class="breadcrumbs__link">мероприятия</a>
			</li>
			<li class="breadcrumbs__item">
				<a href="#" class="breadcrumbs__link">мои мероприятия</a>
			</li>
			<li class="breadcrumbs__item">
				<span href="#" class="breadcrumbs__link breadcrumbs__link_current">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</span>
			</li>
        </ul>		 -->
      <h1 class="section-title mb-50">
        «Анализ и планирование методической работы»
      </h1>
      <div class="content-inner">
        <div class="content__right content__right-polls events-content">
          <div class="content__right-wr">
            <div class="events-content__item">
              <div class="events-title">
                Тема «Педагогическое взаимодействие в структуре методической
                работы как условие совершенствования профессионально-личностных
                компетенций педагога»
              </div>
            </div>
            <div class="events-content__item events-content__item--flex">
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Дата начала опроса</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">23.10.2021</div>
                </div>
              </div>
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Дата конца опроса</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">23.10.2021</div>
                </div>
              </div>
            </div>
            <div class="events-content__item events-content__item--flex">
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Прошли опрос</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">16/34</div>
                </div>
              </div>
              <div
                class="
                  events-content__item-time events-content__item-time--width50
                  item-time
                "
              >
                <div class="events-content__item-name">Всего вопросов</div>
                <div class="events-content__item-info">
                  <div class="events-content__item-record">12</div>
                </div>
              </div>
            </div>
          </div>
          <div class="content__right-wr">
            <div class="events-content__item">
              <div class="events-content__item-name">Дата начала опроса</div>
              <div class="events-title">
                Тема «Педагогическое взаимодействие в структуре методической
                работы как условие совершенствования профессионально-личностных
                компетенций педагога»
              </div>
            </div>
            <div class="events-content__item">
              <label class="form-block__inner">
                <div class="form-block__name name-title">
                  Вопрос 1. введите ответ
                </div>
                <input
                  type="text"
                  class="form-block__input form-block__input-bbn"
                  placeholder="Текстовый ответ"
                />
              </label>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">
                Вопрос 2. Выберите один вариант ответа
              </div>
              <div class="events-content__item-radio box-radio">
                <label class="wr-radio">
                  <input
                    type="radio"
                    name="Вопрос 2"
                    value="Вариант 1"
                    class="real-radio"
                    checked
                  />
                  <span class="custom-radio custom-radio--mb"></span>
                  <span class="text-radio">Вариант 1</span>
                </label>
                <label class="wr-radio">
                  <input
                    type="radio"
                    name="Вопрос 2"
                    value="Вариант 2"
                    class="real-radio"
                  />
                  <span class="custom-radio custom-radio--mb"></span>
                  <span class="text-radio">Вариант 2</span>
                </label>
                <label class="wr-radio">
                  <input
                    type="radio"
                    name="Вопрос 2"
                    value="Вариант 3"
                    class="real-radio"
                  />
                  <span class="custom-radio"></span>
                  <span class="text-radio">Вариант 3</span>
                </label>
              </div>
            </div>
            <div class="events-content__item">
              <div class="events-content__item-name">
                Вопрос 3. выберите несколько вариантов ответа
              </div>
              <div class="events-content__item-radio">
                <label class="wr-checkbox wr-checkbox--mb">
                  <input
                    type="checkbox"
                    name="coding-notes"
                    class="real-checkbox"
                  />
                  <span class="custom-checkbox custom-checkbox--grey"></span>
                  <span class="text-checkbox text-checkbox--grey"
                    >Вариант 1</span
                  >
                </label>
                <label class="wr-checkbox wr-checkbox--mb">
                  <input
                    type="checkbox"
                    name="coding-notes"
                    class="real-checkbox"
                  />
                  <span class="custom-checkbox custom-checkbox--grey"></span>
                  <span class="text-checkbox text-checkbox--grey"
                    >Вариант 2</span
                  >
                </label>
                <label class="wr-checkbox wr-checkbox--mb">
                  <input
                    type="checkbox"
                    name="coding-notes"
                    class="real-checkbox"
                  />
                  <span class="custom-checkbox custom-checkbox--grey"></span>
                  <span class="text-checkbox text-checkbox--grey"
                    >Вариант 3</span
                  >
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="events-content__item-button">
        <button
          type="submit"
          class="
            button button--mr button_theme_green button_border_small
            form__submit
            button_news
          "
        >
          Отравить
        </button>
        <button
          type="submit"
          class="
            button
            button_theme_green--empty
            button_border_small
            form__submit
            button_news
          "
        >
          Сохранить в черновик
        </button>
      </div>
    </section>
  </main>
</template>
