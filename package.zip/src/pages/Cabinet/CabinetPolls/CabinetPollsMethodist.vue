<template>
    <main class="content content_federal">
		<section class="users page__section">        
			<div class="users__top">
				<h1 class="section-title">Опросы</h1>
				<div class="users__top-btn">
					<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Создать опрос</button>
				</div>					
			</div>
			<div class="form-detail__wrapper wrapper-max_width-m">
				<div class="tabs form-detail__tabs _tabs">
					<nav class="tabs__navigation">
						<button type="submit" class="tabs__title _tabs-item _active">Опросы</button>
						<button type="submit" class="tabs__title _tabs-item ">Черновики</button>						
					</nav>
					<div class="tabs__content">
						<div class="tabs__body _tabs-block  _active">
							<div class="events-wrap">    
								<div class="events-row events-row--jc">
									<h3 class="events__title events__title--icon">Текущие опросы</h3>
									<div class="events__filter">
										<div class="events__filter-item">
											<div class="events__filter-box-arrow box-arrow">
												<div class="arrow arrow-up"><img loading='lazy' width='7' height='5' src='./images/arrow_up.svg' alt='стрелка вверх'></div>
												<div class="arrow arrow-do"><img loading='lazy' width='7' height='5' src='./images/arrow_down.svg' alt='стрелка вниз'></div>
											</div>
											<div class="events__filter-name">Дата</div>
										</div>
										<div class="events__filter-item">
											<div class="events__filter-box-arrow box-arrow">
												<div class="arrow arrow-up"><img loading='lazy' width='7' height='5' src='./images/arrow_up.svg' alt='стрелка вверх'></div>
												<div class="arrow arrow-do"><img loading='lazy' width='7' height='5' src='./images/arrow_down.svg' alt='стрелка вниз'></div>
											</div>
											<div class="events__filter-name">Тип</div>
										</div>
									</div>
								</div>
								<div class="events-row events-card-wr">
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user"><span>32</span> из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Завершить</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user"><span>32</span> из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Завершить</button>
											<a href="#" class="new-card-btn__link">Подробнее</a>								
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user"><span>32</span> из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Завершить</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user"><span>32</span> из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Завершить</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>						
								</div>
								<div class="events-row events-row--jc">
									<h3 class="events__title">Завершенные опросы</h3>						
								</div>
								<div class="events-row events-card-wr">
									<article class="events-card">
										<div class="events-card__title events-card__title--grey">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal-grey">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user-grey">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q-grey">16 впросов</div>
										</div>										
										<div class="events-card__btn">								
											<a href="#" class="new-card-btn__link">Подробнее</a>
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title events-card__title--grey">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal-grey">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user-grey">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q-grey">16 впросов</div>
										</div>										
										<div class="events-card__btn">								
											<a href="#" class="new-card-btn__link">Подробнее</a>
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title events-card__title--grey">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal-grey">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user-grey">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q-grey">16 впросов</div>
										</div>										
										<div class="events-card__btn">								
											<a href="#" class="new-card-btn__link">Подробнее</a>
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title events-card__title--grey">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal-grey">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user-grey">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q-grey">16 впросов</div>
										</div>										
										<div class="events-card__btn">								
											<a href="#" class="new-card-btn__link">Подробнее</a>
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title events-card__title--grey">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal-grey">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user-grey">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q-grey">16 впросов</div>
										</div>										
										<div class="events-card__btn">								
											<a href="#" class="new-card-btn__link">Подробнее</a>
										</div>
									</article>						
									<article class="events-card">
										<div class="events-card__title events-card__title--grey">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal-grey">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user-grey">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q-grey">16 впросов</div>
										</div>										
										<div class="events-card__btn">								
											<a href="#" class="new-card-btn__link">Подробнее</a>
										</div>
									</article>						
								</div>
							</div>                    
						</div>
						<div class="tabs__body _tabs-block">
							<div class="events-wrap">    
								<div class="events-row events-card-wr">
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Опубликовать</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>																		
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Опубликовать</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>																		
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Опубликовать</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>																		
									<article class="events-card">
										<div class="events-card__title">«Мастер-класс как эффективная форма повышения профессионального мастерства педагогов»</div>										
										<div class="events-card__wr-text">
											<div class="events-card__text events-card__text--cal">20 января 2022 - 23 января 2022</div>
											<div class="events-card__text events-card__text--user">32 из 48  прошли опрос</div>
											<div class="events-card__text events-card__text--q">16 впросов</div>
										</div>										
										<div class="events-card__btn">
											<button type="submit" class="button button_theme_green button_border_small form__submit button_news">Опубликовать</button>	
											<a href="#" class="new-card-btn__link">Подробнее</a>							
										</div>
									</article>																		
								</div>
							</div>                    
						</div>
						
					</div>
				</div>
			</div>        
		</section>
    </main>    
</template>