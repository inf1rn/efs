import SearchInput from "./SearchInput"
import DataBlock from "./DataBlock"
import Pagination from "./Pagination"

export default [SearchInput, DataBlock, Pagination]